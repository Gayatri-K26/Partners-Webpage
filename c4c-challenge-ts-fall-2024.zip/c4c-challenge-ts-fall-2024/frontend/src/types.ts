export interface PartnerData {
    id: string;
    name: string;
    description: string;
    thumbnailUrl: string;
    active: boolean;
}